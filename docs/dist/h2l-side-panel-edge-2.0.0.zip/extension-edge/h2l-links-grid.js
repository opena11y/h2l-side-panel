/* h2l-links-grid.js */

/* Imports */

import DebugLogging   from './debug.js';


import {
  getMessage,
  getSpan,
  getSpanBrackets,
  highlightItems,
  removeChildContent,
  setI18nLabels,
  setTablistAttr
} from './utils.js';

import {
  getOptions,
  saveOption
} from './storage.js';

import {
  TabpanelOptions
} from './h2l-tabpanel-options.js';

/* Constants */

const debug = new DebugLogging('h2lLinksGrid', false);
debug.flag = false;

const isMozilla = typeof browser === 'object';
const isWin     = navigator.userAgent.includes('Windows');

const gridOffsetWidth = ( isWin && !isMozilla) ?
                            51 :
                            36;

const LINK_ROLE = 'A';

/* templates */
const template = document.createElement('template');
template.innerHTML = `
  <table role="grid">
    <thead>
       <tr id="id-tr-sort"
           data-i18n-aria-label="links_sorting_options_row">
          <th id="id-th-pos"
              tabindex="-1"
              class="position"
              data-sort="position"
              aria-sort="ascending">
            <span class="label"
                  data-i18n="links_grid_position">
            </span>
            <span class="icon">
              <svg xmlns="http://www.w3.org/2000/svg"
                   width="1em"
                   height="1em"
                   viewbox="0 0 32 32">
                  <polygon points="4,8 28,8 16,28"/>
              </svg>
            </span>
          </th>
          <th id="id-th-name"
              tabindex="-1"
              class="name"
              data-sort="name"
              aria-sort="none">
            <span class="label"
                  data-i18n="links_grid_name">
            </span>
            <span class="icon">
              <svg xmlns="http://www.w3.org/2000/svg"
                   width="1em"
                   height="1em"
                   viewbox="0 0 32 32">
                  <polygon points="4,8 28,8 16,28"/>
              </svg>
            </span>
          </th>
          <th id="id-th-desc"
              tabindex="-1"
              class="desc"
              data-sort="desc"
              aria-sort="none"
              aria-label="links_grid_desc_name">
            <span class="label"
                  data-i18n="links_grid_desc">
            </span>
            <span class="icon">
              <svg xmlns="http://www.w3.org/2000/svg"
                   width="1em"
                   height="1em"
                   viewbox="0 0 32 32">
                  <polygon points="4,8 28,8 16,28"/>
              </svg>
            </span>
          </th>
          <th id="id-th-type"
              tabindex="-1"
              class="type"
              data-sort="type"
              aria-sort="none">
            <span class="label"
                  data-i18n="links_grid_type">
            </span>
            <span class="icon">
              <svg xmlns="http://www.w3.org/2000/svg"
                   width="1em"
                   height="1em"
                   viewbox="0 0 32 32">
                  <polygon points="4,8 28,8 16,28"/>
              </svg>
            </span>
          </th>
       </tr>
    </thead>
    <tbody id="id-grid-data">
    </tbody>
  </table>

  <div id="options">
    <div class="flex">
      <div class="column">
        <label for="highlight-all">
          <input id="highlight-all"
                 type="checkbox"
                 data-option="highlightAllLinks"/>
          <span data-i18n="options_highlight_links_all"></span>
        </label>
        <label for="show-name">
          <input id="show-name"
                 type="checkbox"
                 data-option="highlightNamesLinks"/>
          <span data-i18n="options_highlight_link_names"></span>
        </label>
      </div>
      <div class="column">
            <button id="id-btn-options"
                    data-i18n="buttons_options_link_filter">
            </button>
      </div>
    </div>
  </div>

  <h2l-link-filter-dialog>
  </h2l-link-filter-dialog>
`;

class H2LLinksGrid extends HTMLElement {
  constructor () {
    super();
    this.attachShadow({ mode: 'open' });

    // Use external CSS stylesheet
    const linkGrid = document.createElement('link');
    linkGrid.setAttribute('rel', 'stylesheet');
    linkGrid.setAttribute('href', './h2l-links-grid.css');
    this.shadowRoot.appendChild(linkGrid);

    // Use external CSS stylesheet for focus styling
    const linkFocus = document.createElement('link');
    linkFocus.setAttribute('rel', 'stylesheet');
    linkFocus.setAttribute('href', './h2l-focus-style.css');
    linkFocus.id = 'focus-style';
    this.shadowRoot.appendChild(linkFocus);

    // Use external CSS stylesheet for options styling
    const linkOptions = document.createElement('link');
    linkOptions.setAttribute('rel', 'stylesheet');
    linkOptions.setAttribute('href', './h2l-tabpanel-options.css');
    linkOptions.id = 'tabpanel-options';
    this.shadowRoot.appendChild(linkOptions);


    // Add DOM tree from template
    this.shadowRoot.appendChild(template.content.cloneNode(true));

    this.gridNode = this.shadowRoot.querySelector('[role="grid"]');

    const trNode = this.shadowRoot.querySelector('[role="grid"] thead tr');
    trNode.addEventListener('keydown', this.handleGridrowKeydown.bind(this));
    trNode.addEventListener('focus',   this.handleFocus.bind(this));
    trNode.addEventListener('blur',    this.handleBlur.bind(this));

    this.thNodes = Array.from(this.shadowRoot.querySelectorAll('[role="grid"] thead th'));

    this.thNodes.forEach( (thNode) => {
      thNode.addEventListener('click',   this.handleClickSort.bind(this));
      thNode.addEventListener('keydown', this.handleGridcellKeydown.bind(this));
      thNode.addEventListener('focus',   this.handleFocus.bind(this));
      thNode.addEventListener('blur',    this.handleBlur.bind(this));
    });

    this.gridTbodyNode = this.shadowRoot.querySelector('[role="grid"] tbody');

    this.h2lLinkFilterDialog  = this.shadowRoot.querySelector('h2l-link-filter-dialog');

    const btnOptions      = this.shadowRoot.querySelector('#id-btn-options');
    btnOptions.addEventListener('click', this.handleOptionsClick.bind(this));

    this.checkboxHighlightAll = this.shadowRoot.querySelector("#highlight-all");
    this.checkboxHighlightAll.addEventListener('click', this.handleHighlightAllChange.bind(this));

    this.checkboxShowNames    = this.shadowRoot.querySelector("#show-name");

    this.posWidth  = 0;
    this.nameWidth = 0;
    this.descWidth  = 0;
    this.typeWidth  = 0;

    this.highlightFollowsFocus = false;
    this.enterKeyMovesFocus    = false;
    this.isVisible = false;
    this.lastLinkId = '';
    this.links = [];
    this.linkItems = [];

    this.filteredCount = 0;
    this.hiddenCount   = 0;
    this.visibleCount  = 0;

    setI18nLabels(this.shadowRoot, debug.flag);

    this.tabpanelOptions = new TabpanelOptions(this.shadowRoot);

    getOptions().then( (options) => {
      this.checkboxShowNames.disabled = !options.highlightAllLinks;
    });
  }

 static get observedAttributes() {
    return [
      "visible",
      ];
  }


  attributeChangedCallback(name, oldValue, newValue) {

    switch (name) {
      case "visible":
        this.isVisible = newValue.toLowerCase() === 'true';
        break;

      default:
        break;
    }
  }

  resize (height, width) {
    const tableWidth = width;

    this.gridNode.style.width = tableWidth + 'px';

    const posWidth  = 50;
    const descWidth = 58;
    const typeWidth = 58;
    const nameWidth = tableWidth - posWidth - descWidth - typeWidth - gridOffsetWidth;

    this.posWidth   = posWidth + 'px';
    this.nameWidth  = nameWidth + 'px';
    this.descWidth  = descWidth + 'px';
    this.typeWidth  = typeWidth + 'px';

    const posNodes = Array.from(this.gridNode.querySelectorAll('.position'));
    posNodes.forEach( (n) => {
      n.style.width = this.posWidth;
    });

    const nameNodes = Array.from(this.gridNode.querySelectorAll('.name'));
    nameNodes.forEach( (n) => {
      n.style.width = this.nameWidth;
    });

    const descNodes = Array.from(this.gridNode.querySelectorAll('.desc'));
    descNodes.forEach( (n) => {
      n.style.width = this.descWidth;
    });

    const typeNodes = Array.from(this.gridNode.querySelectorAll('.type'));
    typeNodes.forEach( (n) => {
      n.style.width = this.typeWidth;
    });

    const optionsNode = this.shadowRoot.querySelector("#options");
    const optionsRect = optionsNode.getBoundingClientRect();

    this.gridNode.style.height = (height - 1.2 * optionsRect.height) + 'px';

  }

  addMessage (message, tabindexValue=0, className='message') {
     if ((typeof message === 'string') && message.length) {

       const trNode = document.createElement('tr');
       trNode.tabIndex = tabindexValue;
       trNode.addEventListener('click',   this.handleMessageGridrowClick.bind(this));
       trNode.addEventListener('keydown', this.handleGridrowKeydown.bind(this));
       trNode.addEventListener('focus',   this.handleFocus.bind(this));
       trNode.addEventListener('blur',    this.handleBlur.bind(this));

       this.gridTbodyNode.appendChild(trNode);

       const msgNode =  document.createElement('td');
       msgNode.setAttribute('colspan', 4);
       msgNode.textContent = message;
       msgNode.className = className;
       msgNode.setAttribute('tabindex', '-1');
       msgNode.addEventListener('keydown', this.handleMessageGridcellKeydown.bind(this));
       msgNode.addEventListener('focus',   this.handleFocus.bind(this));
       msgNode.addEventListener('blur',    this.handleBlur.bind(this));

       trNode.appendChild(msgNode);

     }
  }

  clearContent (message = '') {
     removeChildContent(this.gridTbodyNode);
     this.addMessage(message);
  }

  updateMessages(filteredCount, hiddenCount, visibleCount) {
    if (filteredCount > 0) {
      filteredCount === 1 ?
        this.addMessage(getMessage('msg_filtered_link'), (visibleCount ? -1 : 0), 'filtered') :
        this.addMessage(`${filteredCount} ${getMessage('msg_filtered_links')}`, (visibleCount ? -1 : 0), 'filtered');
    }

    if (hiddenCount) {
      hiddenCount === 1 ?
        this.addMessage(getMessage('msg_hidden_link'), (visibleCount ? -1 : 0), 'hidden') :
        this.addMessage(`${hiddenCount} ${getMessage('msg_hidden_links')}`, (visibleCount ? -1 : 0), 'hidden');
    }

  }

  updateContent (sameUrl, links, filteredCount) {
    const linksObj = this;
    this.filteredCount = filteredCount;

    this.links = links.filter( (link) => {
      return link.isVisibleOnScreen || link.isVisibleToAT;
    });

    this.hiddenCount = links.length - this.links.length;

    if (this.links) {

      getOptions().then( (options) => {

        linksObj.highlightFollowsFocus = options.highlightFollowsFocus;
        linksObj.enterKeyMovesFocus    = options.enterKeyMovesFocus;
        linksObj.lastURL               = options.lastURL;
        linksObj.lastLinkId            = options.lastLinkId;

        linksObj.links.forEach( (link, index) => {

          linksObj.linkItems.push({
            position: link.ordinalPosition,
            isVisibleOnScreen: link.isVisibleOnScreen,
            isVisibleToAT:     link.isVisibleToAT,
            elemRole: LINK_ROLE
          });

          [link.type, link.typeDesc, link.typeSort] = linksObj.getTypeContentAndDescription(link);
          link.pos = index + 1;

          if ((link.name && link.desc) &&
              (link.name.trim().toLowerCase() === link.desc.trim().toLowerCase())) {
            link.desc = '';
            link.descSource = '';
          }

          if (link.name !== link.desc) {
            link.descValue = link.desc.length === 0 ? 1 : 2;
          }

        });

        const lastGridNode = linksObj.updateLinkContent(this.links);

        const firstGridrow = linksObj.gridNode.querySelector('[role="grid"] tbody tr');

        this.visibleCount = linksObj.gridNode.querySelectorAll('[role="grid"] tbody tr').length;
        setTablistAttr('links-count', this.visibleCount);

        if (firstGridrow) {
          if (sameUrl && lastGridNode) {
            linksObj.setFocusToGriditem(lastGridNode);
          }
          else {
            linksObj.setFocusToGriditem(firstGridrow);
          }
        }
        else {
          linksObj.clearContent(getMessage('links_none_found', debug.flag));
        }
        if (options.highlightAllLinks) {
          highlightItems({}, linksObj.linkItems, getMessage('msg_link_hidden'), options.highlightNamesLinks);
        }

      });

    }
    else {
      this.clearContent(getMessage('protocol_not_supported', debug.flag));
    }

    this.tabpanelOptions.updateOptions();
  }

  updateLinkContent (links) {
    const linksObj = this;
    let lastGridNode = null;
    let hiddenLinks = 0;

    function addRow (pos, ordinalPos, name, nameSource, desc, descSource, descValue, url, typeContent, typeDesc, typeSort, isVisibleOnScreen, isVisibleToAT) {

      // Adding row helper function

      function getDataCell(id, cname, content, desc, title, sortValue, width, isVisScr=true, isVisAT=true, noNameMessage='') {


        const cellNode =  document.createElement('td');
        cellNode.id = id;
        cellNode.className = cname;

        if (noNameMessage && !content) {
          cellNode.appendChild(getSpan(noNameMessage, 'content noname'));
        }
        else {
          cellNode.appendChild(getSpan(content, 'content'));
        }

        if (desc) {
          cellNode.appendChild(getSpan(`; ${desc}`, 'desc'));
        }

        if (!isVisScr) {
          cellNode.appendChild(getSpanBrackets(getMessage('msg_link_hidden_from_screen'), 'hidden', '; hidden'));
        }

        if (!isVisAT) {
          cellNode.appendChild(getSpanBrackets(getMessage('msg_link_hidden_from_at'), 'hidden', '; hidden from AT'));
        }

        if (title) {
          cellNode.title = title;
        }
        if (sortValue) {
          cellNode.setAttribute('data-sort-value', sortValue);
        }
        cellNode.style.width = width;
        cellNode.setAttribute('tabindex', '-1');
        cellNode.addEventListener('keydown', linksObj.handleGridcellKeydown.bind(linksObj));
        cellNode.addEventListener('focus',   linksObj.handleFocus.bind(linksObj));
        cellNode.addEventListener('blur',    linksObj.handleBlur.bind(linksObj));

        if (cellNode.id === linksObj.lastLinkId) {
          lastGridNode = cellNode;
        }
        return cellNode;
      }

      // Start adding new row

      const trNode = document.createElement('tr');
      trNode.id = 'row-' + pos;
      trNode.title = url;
      const accNameForRow = pos + ', ' + name + ', ' + typeDesc;
      trNode.setAttribute('aria-label', accNameForRow);
      trNode.setAttribute('data-ordinal-position', ordinalPos);

      if (trNode.id === linksObj.lastLinkId) {
        lastGridNode = trNode;
      }

      trNode.setAttribute('data-index', pos);
      trNode.setAttribute('tabindex', '-1');
      const firstChar = name.length ? name[0].toLowerCase() : '';
      trNode.setAttribute('data-first-char', firstChar);
      trNode.setAttribute('data-role', LINK_ROLE);
      trNode.setAttribute('data-name', name);
      trNode.setAttribute('data-name-src', nameSource);
      trNode.setAttribute('data-desc', desc);
      trNode.setAttribute('data-desc-src', descSource);
      trNode.setAttribute('data-visible-screen', isVisibleOnScreen);
      trNode.setAttribute('data-visible-at', isVisibleToAT);

      trNode.addEventListener('click',   linksObj.handleGridrowClick.bind(linksObj));
      trNode.addEventListener('keydown', linksObj.handleGridrowKeydown.bind(linksObj));
      trNode.addEventListener('focus',   linksObj.handleFocus.bind(linksObj));
      trNode.addEventListener('blur',    linksObj.handleBlur.bind(linksObj));

      trNode.appendChild(getDataCell(trNode.id + '-pos',
                                     'position',
                                     pos,
                                     '',
                                     '',
                                     '',
                                     linksObj.posWidth));

      trNode.appendChild(getDataCell(trNode.id + '-name',
                                     'name',
                                     name,
                                     desc,
                                     '',
                                     '',
                                     linksObj.nameWidth,
                                     isVisibleOnScreen,
                                     isVisibleToAT,
                                     getMessage(`msg_no_acc_name`)));

      trNode.appendChild(getDataCell(trNode.id + '-desc',
                                     'desc',
                                     desc ? 'Yes' : ' ',
                                     '',
                                     '',
                                     descValue,
                                     linksObj.descWidth));

      trNode.appendChild(getDataCell(trNode.id + '-type',
                                     'type',
                                     typeContent,
                                     '',
                                     typeDesc,
                                     typeSort,
                                     linksObj.typeWidth));
      return trNode;
    }

    this.clearContent();

    links.forEach( (link) => {
      const rowNode = addRow(link.pos,
                             link.ordinalPosition,
                             link.name,
                             link.nameSource,
                             link.desc,
                             link.descSource,
                             link.descValue,
                             link.url,
                             link.type,
                             link.typeDesc,
                             link.typeSort,
                             link.isVisibleOnScreen,
                             link.isVisibleToAT);

      this.gridTbodyNode.appendChild(rowNode);
    });

    this.updateMessages(this.filteredCount, this.hiddenCount, this.visibleCount);

    return lastGridNode;
  }

  getTypeContentAndDescription(link) {

    let linkTypeContent = '';
    let linkTypeDesc    = '';
    let linkTypeSort = 0;

    if (link.extensionType) {
      switch (link.extensionType) {
        case 'pdf':
          linkTypeContent = link.extension;
          linkTypeDesc    = getMessage('link_name_pdf');
          linkTypeSort = 1;
          break;

        case 'doc':
          linkTypeContent = link.extension;
          linkTypeDesc    = getMessage('link_name_doc');
          linkTypeSort = 2;
          break;

        case 'media':
          linkTypeContent = link.extension;
          linkTypeDesc    = getMessage('link_name_media');
          linkTypeSort = 3;
          break;

        case 'zip':
          linkTypeContent = link.extension;
          linkTypeDesc    = getMessage('link_name_zip');
          linkTypeSort = 4;
          break;

        default:
          linkTypeContent = link.extension;
          linkTypeDesc    = '';
          break;
      }
    }
    else {
      if (link.isInternal) {
        linkTypeContent = getMessage('link_name_internal');
        linkTypeDesc    = '';
        linkTypeSort = 11;
      }
      else {
        if (link.isSameSubDomain) {
          linkTypeContent = getMessage('link_abbr_same_sub_domain');
          linkTypeDesc    = getMessage('link_name_same_sub_domain');
          linkTypeSort = 12;
        }
        else {
          if (link.isSameDomain) {
            linkTypeContent = getMessage('link_abbr_same_domain');
            linkTypeDesc    = getMessage('link_name_same_domain');
            linkTypeSort = 13;
          }
          else {
            linkTypeContent = getMessage('link_name_external');
            linkTypeDesc    = '';
            linkTypeSort = 14;
         }
        }
      }
    }
    return [linkTypeContent, linkTypeDesc, linkTypeSort];
  }

  sortRows(sortColumn, direction) {

    function nameCompare(a, b) {
      const aStr = a.name.toLowerCase().trim();
      const bStr = b.name.toLowerCase().trim();
      const result = aStr.localeCompare(bStr);
      if (result === 0) {
        return posCompare(a, b);
      }
      return result;
    }

    function nameCompareDescending(a, b) {
      const aStr = a.name.toLowerCase().trim();
      const bStr = b.name.toLowerCase().trim();
      const result = bStr.localeCompare(aStr);
      if (result === 0) {
        return posCompareDescending(a, b);
      }
      return result;
    }

    function typeCompare(a, b) {
      const result = a.typeSort - b.typeSort;
      if (result === 0) {
        return posCompare(a, b);
      }
      return result;
    }

    function typeCompareDescending(a, b) {
      const result = b.typeSort - a.typeSort;
      if (result === 0) {
        return posCompareDescending(a, b);
      }
      return result;
    }

    function posCompare(a, b) {
      return a.pos - b.pos;
    }

    function posCompareDescending(a, b) {
      return b.pos - a.pos;
    }

    function descCompare(a, b) {
      const result = a.descValue - b.descValue;
      if (result === 0) {
        return posCompare(a, b);
      }
      return result;
    }

    function descCompareDescending(a, b) {
      const result = b.descValue - a.descValue;
      if (result === 0) {
        return posCompareDescending(a, b);
      }
      return result;
    }


    switch (sortColumn) {
      case 'name':
        direction === 'ascending' ?
        this.links.sort(nameCompare) :
        this.links.sort(nameCompareDescending);
        break;

      case 'desc':
        direction === 'ascending' ?
        this.links.sort(descCompare) :
        this.links.sort(descCompareDescending);
        break;

      case 'type':
        direction === 'ascending' ?
        this.links.sort(typeCompare) :
        this.links.sort(typeCompareDescending);
        break;

      default:
        direction === 'ascending' ?
        this.links.sort(posCompare) :
        this.links.sort(posCompareDescending);
        break;
    }

    this.updateLinkContent(this.links);

    // Update attributes with new sort information

    this.thNodes.forEach( (th) => {
      if (th.getAttribute('data-sort') === sortColumn) {
        th.setAttribute('aria-sort', direction);
      }
      else {
        th.setAttribute('aria-sort', 'none');
      }
    });
  }

  sortLinks(elem) {
    const dir        = elem.getAttribute('aria-sort');
    const sortColumn = elem.getAttribute('data-sort');
    switch (dir) {
      case 'none':
      case 'descending':
        this.sortRows(sortColumn, 'ascending');
        break;

      default:
        this.sortRows(sortColumn, 'descending');
        break;
    }
  }

  // Tree keyboard navigation methods

  getGridrows () {
    return Array.from(this.gridNode.querySelectorAll('tr'));
  }

  getGriditems () {
    return Array.from(this.gridNode.querySelectorAll('tr, th, td'));
  }

  highlightGriditem(griditem) {

    function getProp (elem, prop, defaultValue='') {
      return elem.hasAttribute(prop) ?
              elem.getAttribute(prop) :
              elem.parentNode.getAttribute(prop) ?
                elem.parentNode.getAttribute(prop) :
                defaultValue;
    }

    const op = getProp(griditem, 'data-ordinal-position');


    getOptions().then( (options) => {

      highlightItems(
        { position: parseInt(op),
          elemRole: LINK_ROLE
         },
        options.highlightAllLinks ? this.linkItems : [],
        getMessage('msg_link_hidden'),
        options.highlightNamesLinks
      );
      saveOption('lastLinkId', griditem.id);
    });

  }

  removeHighlight() {
    getOptions().then( (options) => {
      highlightItems(
        {},
        [],
        getMessage('msg_link_hidden'),
        false
      );
    });
  }

  setFocusByFirstCharacter(gridrow, char){

    function findChar (gridrow) {
      return char === gridrow.getAttribute('data-first-char');
    }

    const gridrows = this.getGridrows();
    let startIndex = gridrows.indexOf(gridrow) + 1;

    const searchOrder = (startIndex < gridrows.length) ?
                        gridrows.splice(startIndex).concat(gridrows.splice(0, startIndex)) :
                        gridrows;
    const result = searchOrder.find(findChar);
    if (result) {
      this.setFocusToGriditem(result);
    }
  }

  setFocusToFirstGridrow() {
    const gridrows = this.getGridrows();
    if (gridrows[0]) {
      this.setFocusToGriditem(gridrows[0]);
    }
  }

  setFocusToLastGridrow() {
    const gridrows = this.getGridrows();
    if (gridrows.length) {
      this.setFocusToGriditem(gridrows[gridrows.length-1]);
    }
  }

  setFocusToNextGridrow(gridrow) {
    const gridrows = this.getGridrows();
    const index = gridrows.indexOf(gridrow) + 1;
    const nextGridrow = index < gridrows.length ?
                        gridrows[index] :
                        false;

    if (nextGridrow) {
      this.setFocusToGriditem(nextGridrow);
    }
  }

  setFocusToPreviousGridrow(gridrow) {
    const gridrows = this.getGridrows();
    const index = gridrows.indexOf(gridrow) - 1;
    const prevGridrow = index >= 0 ?
                        gridrows[index] :
                        false;

    if (prevGridrow) {
      this.setFocusToGriditem(prevGridrow);
    }
  }

  setFocusToGriditem(griditem) {
    this.setTabindex(griditem);
    if (this.isVisible) {
      griditem.focus();
    }
  }

  setFocusToPreviousGridrowAndCell(gridcell) {
    const linksObj = this;

    function findCellInRow(gridrow, className) {
      if (gridrow) {
        const gridcell = gridrow.querySelector(`.${className}`);
        if (gridcell) {
          linksObj.setFocusToGriditem(gridcell);
          return true;
        }
      }
      return false;
    }

    const className = gridcell.className;

    if (!findCellInRow(gridcell.parentNode.previousElementSibling, className)) {
      const gridTbody = gridcell.parentNode.parentNode;
      if (gridTbody && gridTbody.previousElementSibling) {
        findCellInRow(gridTbody.previousElementSibling.firstElementChild, className);
      }
    }
  }

  setFocusToNextGridrowAndCell(gridcell) {
    const linksObj = this;

    function findCellInRow(gridrow, className) {
      if (gridrow) {
        const gridcell = gridrow.querySelector(`.${className}`);
        if (gridcell) {
          linksObj.setFocusToGriditem(gridcell);
          return true;
        }
      }
      return false;
    }

    const className = gridcell.className;

    if (!findCellInRow(gridcell.parentNode.nextElementSibling, className)) {
      const gridTbody = gridcell.parentNode.parentNode;
      if (gridTbody && gridTbody.nextElementSibling) {
        findCellInRow(gridTbody.nextElementSibling.firstElementChild, className);
      }
    }
  }

  setFocusToNextGridcell(gridcell) {
    const nextGridcell = gridcell.nextElementSibling;
    if (nextGridcell) {
      this.setFocusToGriditem(nextGridcell);
    }
  }

  setFocusToPreviousGridcell(gridcell) {
    const prevGridcell = gridcell.previousElementSibling;
    if (prevGridcell) {
      this.setFocusToGriditem(prevGridcell);
    }
    else {
      this.setFocusToGriditem(gridcell.parentNode);
    }
  }

  setFocusToFirstGridcell(griditem) {
    if (griditem.tagName === 'TR') {
      this.setFocusToGriditem(griditem.firstElementChild);
    }
    else {
      this.setFocusToGriditem(griditem.parentNode.firstElementChild);
    }
  }

  setFocusToLastGridcell(gridcell) {
    this.setFocusToGriditem(gridcell.parentNode.lastElementChild);
  }

  setTabindex(griditem) {
    const griditems = this.getGriditems();
    griditems.forEach( (gi) => {
      gi.setAttribute('tabindex', (gi === griditem) ? 0 : -1);
    });
  }


  // Event handlers

  handleFocus(event) {
    const tgt = event.currentTarget;
    if (this.highlightFollowsFocus) {
      this.highlightGriditem(tgt);
    }
  }

  handleBlur() {
    this.removeHighlight()
  }

  handleClickSort(event) {
    const tgt = event.currentTarget;
    this.sortLinks(tgt);
    event.stopPropagation();
    event.preventDefault();
  }

  handleGridrowClick (event) {
    const tgt = event.currentTarget;
    const iconNode = tgt.querySelector('.expand-icon');

    // if clicked on expand icon in the treeview then do not process event
    if (!iconNode ||
        (iconNode && (iconNode !== event.target)) ||
        (iconNode && !iconNode.contains(event.target))) {
      this.setFocusToGriditem(tgt);
      this.highlightGriditem(tgt);
      event.stopPropagation();
      event.preventDefault();
    }
  }

 handleGridrowKeydown(event) {
    const tgt = event.currentTarget;
    const key = event.key;
    let flag  = false;

    function isPrintableCharacter(str) {
      return str.length === 1 && str.match(/\S/);
    }

    if (event.shiftKey || event.altKey || event.ctrlKey || event.metaKey) {
      return;
    }

    switch (key) {
      case 'Enter':
      case ' ':
        this.highlightGriditem(tgt);
        flag = true;
        break;

      case 'ArrowUp':
        this.setFocusToPreviousGridrow(tgt);
        flag = true;
        break;

      case 'ArrowDown':
        this.setFocusToNextGridrow(tgt);
        flag = true;
        break;

      case 'ArrowRight':
        this.setFocusToFirstGridcell(tgt);
        flag = true;
        break;

      case 'ArrowLeft':
        flag = true;
        break;

      case 'Home':
        this.setFocusToFirstGridrow();
        flag = true;
        break;

      case 'End':
        this.setFocusToLastGridrow();
        flag = true;
        break;

      default:
        if (isPrintableCharacter(key)) {
          this.setFocusByFirstCharacter(tgt, key);
          flag = true;
        }
        break;
    }

    if (flag) {
      event.stopPropagation();
      event.preventDefault();
    }
  }

 handleGridcellKeydown(event) {
    const tgt = event.currentTarget;
    const key = event.key;
    let flag  = false;

    if (event.shiftKey || event.altKey || event.ctrlKey || event.metaKey) {
      return;
    }

    switch (key) {
      case 'Enter':
      case ' ':
        if (tgt.hasAttribute('data-sort')) {
          this.sortLinks(tgt);
        }
        else {
          this.highlightGriditem(tgt.parentNode);
        }
        flag = true;
        break;

      case 'ArrowUp':
        this.setFocusToPreviousGridrowAndCell(tgt);
        flag = true;
        break;

      case 'ArrowDown':
        this.setFocusToNextGridrowAndCell(tgt);
        flag = true;
        break;

      case 'ArrowRight':
        this.setFocusToNextGridcell(tgt);
        flag = true;
        break;

      case 'ArrowLeft':
        this.setFocusToPreviousGridcell(tgt);
        flag = true;
        break;

      case 'Home':
        this.setFocusToFirstGridcell(tgt);
        flag = true;
        break;

      case 'End':
        this.setFocusToLastGridcell(tgt);
        flag = true;
        break;

      default:
        break;
    }

    if (flag) {
      event.stopPropagation();
      event.preventDefault();
    }
  }

  handleMessageGridrowClick (event) {
    const tgt = event.currentTarget;
    this.setFocusToGriditem(tgt);
    event.stopPropagation();
    event.preventDefault();
  }

 handleMessageGridcellKeydown(event) {
    const tgt = event.currentTarget;
    const key = event.key;
    let flag  = false;

    if (event.shiftKey || event.altKey || event.ctrlKey || event.metaKey) {
      return;
    }

    switch (key) {
      case 'ArrowUp':
        this.setFocusToPreviousGridrowAndCell(tgt);
        flag = true;
        break;

      case 'ArrowDown':
        this.setFocusToNextGridrowAndCell(tgt);
        flag = true;
        break;

      case 'ArrowRight':
        this.setFocusToNextGridcell(tgt);
        flag = true;
        break;

      case 'Home':
        this.setFocusToFirstGridcell(tgt);
        flag = true;
        break;

      case 'End':
        this.setFocusToLastGridcell(tgt);
        flag = true;
        break;

      default:
        break;
    }

    if (flag) {
      event.stopPropagation();
      event.preventDefault();
    }
  }

  handleOptionsClick () {
    this.h2lLinkFilterDialog.openDialog();
  }

  handleHighlightAllChange() {
    this.checkboxShowNames.disabled = !this.checkboxHighlightAll.checked;
  }

}


window.customElements.define('h2l-links-grid', H2LLinksGrid);



